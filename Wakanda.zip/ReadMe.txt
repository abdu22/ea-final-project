Database: wakanda
Server: local
Username: root
Password: root

Database will be automatically created.